import { Suspense } from "react";
import PaymentCallbackClient from "./PaymentCallbackClient";

export const metadata = {
  title: "AstroConsu — Retour paiement",
  description: "Vérification du paiement de votre consultation.",
};

export default function PaymentCallbackPage() {
  return (
    <Suspense
      fallback={
        <div className="page narrow">
          <span className="eyebrow">💳 RETOUR PAIEMENT</span>
          <h1>Vérification du paiement...</h1>
        </div>
      }
    >
      <PaymentCallbackClient />
    </Suspense>
  );
}
